package se.chalmers.dm;
import se.chalmers.dm.Seeder;
import se.chalmers.dm.ConnectionHelper;

import com.github.javafaker.Faker;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Random;

public class SeederTestDriver {
    // IMPORTANT: Do NOT change this code, just uncomment it!
    public static void main(String[] args) throws SQLException {
        Faker faker = new Faker();
        Connection connection = ConnectionHelper.createPostgresConnection();
        Random random = new Random();
        Seeder seeder = new Seeder(faker, connection, random);
        // seeder.dropEverythingWEBPAGE();
        // seeder.dropEverythingUSER();
        System.out.println("Creating user table");
        seeder.createUserTable();
        System.out.println("Inserting fake users");
        seeder.insertFakeUsers(12);
        System.out.println("Creating web page table");
        seeder.createWebPageTable();
        System.out.println("Inserting fake users with webpage");
        seeder.insertFakeUsersWithWebPage(200);
    }
}
